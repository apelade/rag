class MoviesController < ApplicationController

  def similar(how=:director)
    @movies = []
    movie = Movie.find_by_id(params[:id].to_i) # stub
    if ! movie.respond_to?(how) || movie[how] == ''
      handle_missing_info(movie, how)
    else
      @movies = movie.similar(how) # stub
    end
  end
  
  # Nesting this boosted test cov 15% but tests failed intermittently:
  # NoMethodError: undefined method `handle_missing_info'
  def handle_missing_info(movie, missing) 
    if movie
      flash[:notice] = "'#{movie.title}' has no #{missing} info."
      flash.keep
    end
    redirect_to movies_path and return    
  end
  
  def show
    id = params[:id]
    @movie = Movie.find_by_id(id) if id
    @movie = Movie.create!() if ! id
  end

  def index
    sort = params[:sort] || session[:sort]
    case sort
    when 'title'
      ordering,@title_header = {:order => :title}, 'hilite'
    when 'release_date'
      ordering,@date_header = {:order => :release_date}, 'hilite'
    end
    @all_ratings = Movie.all_ratings
    @selected_ratings = params[:ratings] || session[:ratings] || {}
    
    if @selected_ratings == {}
      @selected_ratings = Hash[@all_ratings.map {|rating| [rating, rating]}]
    end
    
    if params[:sort] != session[:sort]
      session[:sort] = sort
      flash.keep
      redirect_to :sort => sort, :ratings => @selected_ratings and return
    end

    if params[:ratings] != session[:ratings] and @selected_ratings != {}
      session[:sort] = sort
      session[:ratings] = @selected_ratings
      flash.keep
      redirect_to :sort => sort, :ratings => @selected_ratings and return
    end
    @movies = Movie.find_all_by_rating(@selected_ratings.keys, ordering)
  end

  def new
    @movie = Movie.new
  end

  def create
    
    @movie = Movie.create(params[:movie])

    if @movie && @movie.valid?
      flash[:notice] = "#{@movie.title} was successfully created."
      redirect_to movies_path and return
    else
      flash[:notice] = "Movie not created successfully."
      # keep user-entered vals in template, try to not discard
      ################### @movie = Movie.new 
      render :action => :new
    end
  end

  def edit
    @movie = Movie.find params[:id]
  end

  # For now, have to update everything at once
  def update
    @movie = Movie.find params[:id] 
    success = @movie.update_attributes(params[:movie])
    if success
      flash[:notice] = "#{@movie.title} was successfully updated."
      redirect_to movie_path(@movie)
    else
      flash[:notice] = "Movie not successfully updated."
      render :action => :edit
    end
  end

  def destroy
    @movie = Movie.find(params[:id])
    @movie.destroy
    flash[:notice] = "Movie '#{@movie.title}' deleted."
    redirect_to movies_path
  end

end
