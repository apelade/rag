class Movie < ActiveRecord::Base
  include ActiveModel::Validations
  
  # cheesily special casing director by omission here
  validates_presence_of :title, :rating, :release_date, on: :create
  
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end

  #TODO: make this a join, offer similar_how
  
  
  #def self.similar(id, how)
  #	target = Movie.find_by_id(id)
  #  return where how => target[how]
  #end

  # Going with the instance method since we have to fetch the movie object in 
  # movies_controller.rb#similar to validate that the director is not blank.
  # So since we already hit the db once, instead of passing an id to similar
  # here as the class method above, just call to the object since
  # it knows it's id.
  def similar(field)
    return [] unless self[field]
  	return Movie.where field => self[field]
  end
end

