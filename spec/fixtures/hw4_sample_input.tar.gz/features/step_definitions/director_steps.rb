Given /the following movies exist/ do |movies_table|
  Movie.create!(movies_table.hashes)
end

Given /^(?:|I )(go to|am on) the (.*) page for "([^"]*)"$/ do |x, action, movie|
  movie_id = Movie.find_by_title(movie).id
  if action.to_s.index('edit')
  	visit "/movies/#{movie_id}/edit"
  	uri = URI.parse(current_url)
  	"#{uri.path}".should == "/movies/#{movie_id}/edit" #TODO: movies_edit_path
  elsif action.to_s.index('detail')
    visit "/movies/#{movie_id}"
  	uri = URI.parse(current_url)
  	"#{uri.path}".should == "/movies/#{movie_id}"    
  end      
end

Then /the director of "([^"]*)" should be "([^"]*)"$/ do |movie, director|
  Movie.find_by_title(movie).director.should == director
end

