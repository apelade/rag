require "spec_helper.rb"
require "movies_controller.rb"
describe MoviesController do
  render_views # magic
  describe 'GET #similar' do
    
    
    before :each do
      @fake_results = [
        stub_model(Movie, id: 1, title: 'Jaws', rating: 'R', release_date: 1981-06-25, director: 'Steven Spielberg'),
        stub_model(Movie, id: 2, title: 'E.T.', rating: 'G', release_date: 1982-12-25, director: 'Steven Spielberg'),
        stub_model(Movie, id: 3, title: 'Camp X', rating: 'R', release_date: 1941-06-25, director: 'Steven Spielberg')
      ]
    end
     
    it 'should query the instance for similar movies' do
      instance = double(Movie)
      instance.stub(:similar).and_return(@fake_results)
      expect(instance.similar).to eq(@fake_results)
    end

    it 'should redirect to the index page if id is not found' do
      get :similar, {:id => 66666666}
      expect(response).to redirect_to movies_path
    end
    
    
    context 'with the relevant model methods stubbed out' do
    
      # TODO: breaks 'redirect to index pg', red flag not isolated
      before :each do
        Movie.any_instance.stub(:similar).and_return(@fake_results)
        new_mov = stub_model(Movie,
         :id => 12, :director =>'Steven Spielberg', :similar => @fake_results)
        new_mov.stub(:similar).and_return(@fake_results)
        Movie.stub(:find_by_id).and_return(new_mov)
      end
         
      it 'should make the model movies available to the Similar template' do
        # id is params in the get message url routed to the named route :similar
        # in routes.rb, not an arg but via params, used in the controller method 
        get :similar, {:id => 'stubbed - ignored'}
        expect(assigns[:movies]).to eq(@fake_results)
      end
      

      it 'should render the Similar template' do
        get :similar, {:id => 'stubbed - ignored'}
        expect(response).to render_template(:similar)
        expect(response.body).to match /Similar Movies/m # brittle
        # TODO: table diff here
      end
      
    end
    
  end
  ########################### Boilerplate from generate scaffold
  # This should return the minimal set of attributes required to create a valid
  # Movie. As you add validations to Movie, be sure to
  # adjust the attributes here as well.
  let(:valid_attributes) { { title: "Buddy", rating: 'G', release_date: '2011-11-11', director: "Martin Scorsese" } }

  # This should return the minimal set of values that should be in the session
  # in order to pass any filters (e.g. authentication) defined in
  # MoviesController. Be sure to keep this updated too.
  let(:valid_session) { {} }

  describe "GET index" do

    
    context 'order and filter params provided' do
      it 'receives params from http call' do
        get :index, {:sort => 'title', :ratings => Movie.all_ratings}, valid_session
        # TODO 1 add the expectation
      end
    end
    
    context 'order or filter params not provided' do
      it "assigns all movies as @movies" do
        movie = Movie.create! valid_attributes
        get :index, {}, valid_session
        assigns(:movies).should eq([movie])
      end
      
      it 'uses previous or default order and filter info from session' do
        valid_session[:sort] = 'title'
        valid_session[:ratings] = {'G' => '1'}
        
        get :index, {}, valid_session
        # selected ratings is all ratings first time
        expect(response).to redirect_to(
          :sort => valid_session[:sort], :ratings => valid_session[:ratings]
        )
      end
      
      it 'inits session sort, ratings and uses them if no params first time' do
        movie = Movie.create! valid_attributes
        all_rat = Hash[Movie.all_ratings.map {|rating| [rating, rating]}]        
        get :index, {:sort => 'release_date'}, valid_session
        expect(assigns[:selected_ratings]).to eq all_rat
      end
      
    end

  end

  describe "GET show" do
    it "assigns the requested movie as @movie" do
      movie = Movie.create! valid_attributes
      Movie.stub(:find_by_id).and_return(movie)    
      get :show, {:id => movie.id}, valid_session
      assigns(:movie).should eq(movie)
    end
  end

  describe "GET new" do
    it "assigns a new movie as @movie" do
      get :new, {}, valid_session
      assigns(:movie).should be_a_new(Movie)
    end
  end

  describe "GET edit" do
    it "assigns the requested movie as @movie" do
      movie = Movie.create! valid_attributes
      get :edit, {:id => movie.to_param}, valid_session
      assigns(:movie).should eq(movie)
    end
  end

  describe "POST create" do
    describe "with valid params" do
      it "creates a new Movie" do
        expect {
          post :create, {:movie => valid_attributes}, valid_session
        }.to change(Movie, :count).by(1)
      end

      it "assigns a newly created movie as @movie" do
        post :create, {:movie => valid_attributes}, valid_session
        assigns(:movie).should be_a(Movie)
        assigns(:movie).should be_persisted
      end

      it "redirects to the home page aka movies page" do
        post :create, {:movie => valid_attributes}, valid_session
        #response.should redirect_to(Movie.last) # PM deviating per courseware
        response.should redirect_to(movies_path)
      end
    end

    describe "with invalid params" do
      it "assigns a newly created but unsaved movie as @movie" do
        # Trigger the behavior that occurs when invalid params are submitted
        Movie.any_instance.stub(:save).and_return(false)
        post :create, {:movie => { "title" => "invalid value" }}, valid_session
        assigns(:movie).should be_a(Movie)
      end
      render_views
      it "re-renders the 'new' template" do
        Movie.any_instance.stub(:save).and_return(false)
        post :create, {:movie => { "title" => "invalid value" }}, valid_session
        response.should render_template(:new)
      end
    end
  end

  describe "PUT update" do
    describe "with valid params" do
      it "updates the requested movie" do
        Movie.delete_all
        movie = Movie.create! valid_attributes
        Movie.any_instance.should_receive(:update_attributes).with({ "title" => "Mars" })
        put :update, {:id => movie.to_param, :movie => { "title" => "Mars" }}, valid_session
        #p response, assigns
      end

      it "assigns the requested movie as @movie" do
        movie = Movie.create! valid_attributes
        put :update, {:id => movie.to_param, :movie => valid_attributes}, valid_session
        assigns(:movie).should eq(movie)
      end

      it "redirects to the movie" do
        movie = Movie.create! valid_attributes
        put :update, {:id => movie.to_param, :movie => valid_attributes}, valid_session
        response.should redirect_to(movie)
      end
    end

    describe "with invalid params" do
      it "assigns the movie as @movie" do

        # Trigger the behavior that occurs when invalid params are submitted
        Movie.any_instance.stub(:save).and_return(false)
        movie = Movie.create! valid_attributes        
        put :update, {:id => movie.to_param, :movie => { "title" => "invalid value" }}, valid_session
        assigns(:movie).should eq(movie)
      end
      
      render_views
      it "re-renders the 'edit' template" do

        # Trigger the behavior that occurs when invalid params are submitted
        Movie.any_instance.stub(:save).and_return(false)
        movie = Movie.create! valid_attributes        
        put :update, {:id => movie.to_param, :movie => { "title" => "invalid value" }}, valid_session
        response.should render_template("edit")
      end
    end
  end

  describe "DELETE destroy" do
    it "destroys the requested movie" do
      movie = Movie.create! valid_attributes
      expect {
        delete :destroy, {:id => movie.to_param}, valid_session
      }.to change(Movie, :count).by(-1)
    end

    it "redirects to the movies list" do
      movie = Movie.create! valid_attributes
      delete :destroy, {:id => movie.to_param}, valid_session
      response.should redirect_to(movies_url)
    end
  end

end

