require 'spec_helper'

describe Movie do

  before :each do
    @fake_results = [
      stub_model(Movie, id: 1, name: 'Jaws', title: 'Jaws', rating: 'R', release_date: 1981-06-25, director: 'Steven Spielberg'),
      stub_model(Movie, id: 2, name: 'E.T.', title: 'E.T.', rating: 'G', release_date: 1982-12-25, director: 'Steven Spielberg'),
      stub_model(Movie, id: 3, name: 'Camp X', title: 'Camp X', rating: 'R', release_date: 1941-06-25, director: 'Steven Spielberg')
    ]
  end

  describe '#similar' do
    it 'asks a movie instance to get those with similar name-vals' do
      Movie.stub(:where).and_return @fake_results
       scorsese = stub_model(Movie, director: 'Martin Scorsese')
       expect(scorsese.similar(:director)).to eq @fake_results
    end  
    it 'returns empty when instance sending has no value for model property' do
       dataless = stub_model(Movie)
       expect( dataless.similar(:director) ).to eq []
    end 
    it 'returns empty when we pass a non-existent model property' do
      bigfoot = stub_model(Movie, foot_size: 50, units: 'cm')
      expect(bigfoot.similar('shoe_size')).to eq []
    end  
  end
  
  #TODO if it should not save Movie.any_instance.stub(:save).and_return(false)
  describe '#all_ratings' do
    it 'returns all the MPAA ratings that exist in the app' do
      Movie.all_ratings.should == %w(G PG PG-13 NC-17 R)
    end 
  end
  
end

